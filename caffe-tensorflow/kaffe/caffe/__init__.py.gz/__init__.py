from .resolver import get_caffe_resolver, has_pycaffe
